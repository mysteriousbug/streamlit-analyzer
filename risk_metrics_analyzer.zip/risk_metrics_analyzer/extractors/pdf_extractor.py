"""Extract tables from PDF files using pdfplumber."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import pdfplumber

from models import MetricRow, TableType
from normalizer import normalize_table


def _find_heading_above_table(page, table_bbox) -> Optional[str]:
    """Find text on the page that sits just above the given table bbox.

    table_bbox is (x0, top, x1, bottom) in pdfplumber coordinates.
    """
    x0, top, x1, bottom = table_bbox
    candidates = []
    for word in page.extract_words() or []:
        w_bottom = float(word["bottom"])
        w_top = float(word["top"])
        if w_bottom > top:
            continue  # Not above
        # Horizontally overlaps (loosely)
        if float(word["x1"]) < x0 - 20 or float(word["x0"]) > x1 + 20:
            continue
        candidates.append((w_top, w_bottom, word["text"]))

    if not candidates:
        return None

    # Group words into lines by proximity, take the closest line above
    candidates.sort(key=lambda c: -c[1])  # Nearest-above first
    closest_bottom = candidates[0][1]
    line_words = [c for c in candidates if abs(c[1] - closest_bottom) < 5]
    line_words.sort(key=lambda c: c[0])
    # Actually we want to sort left-to-right — use x position not available here,
    # but extract_words already returns left-to-right within a line generally.
    # Simpler: re-extract words near that y range properly.
    y_low = closest_bottom - 5
    y_high = closest_bottom + 5
    line = [
        w for w in page.extract_words() or []
        if y_low <= float(w["bottom"]) <= y_high
    ]
    line.sort(key=lambda w: float(w["x0"]))
    return " ".join(w["text"] for w in line).strip() or None


def _page_title(page) -> str:
    """Best-effort page title - topmost line of text."""
    words = page.extract_words() or []
    if not words:
        return ""
    top_y = min(float(w["top"]) for w in words)
    top_line = [w for w in words if float(w["top"]) < top_y + 5]
    top_line.sort(key=lambda w: float(w["x0"]))
    return " ".join(w["text"] for w in top_line).strip()


def extract_from_pdf(
    path: Path,
    domain_hint: str = "",
) -> list[MetricRow]:
    """Extract metric rows from a PDF file."""
    results: list[MetricRow] = []

    with pdfplumber.open(str(path)) as pdf:
        for page in pdf.pages:
            subdomain = _page_title(page)
            # find_tables returns Table objects with .bbox and .extract()
            tables = page.find_tables() or []
            for tbl in tables:
                heading = _find_heading_above_table(page, tbl.bbox) or ""
                table_type = TableType.match(heading) or TableType.match(subdomain)
                if table_type is None:
                    continue

                raw = tbl.extract() or []
                # Normalize: ensure all cells are strings
                raw = [[("" if c is None else str(c)).strip() for c in row] for row in raw]

                rows = normalize_table(
                    raw_table=raw,
                    table_type=table_type,
                    source_file=str(path),
                    domain=domain_hint,
                    subdomain=subdomain,
                )
                results.extend(rows)
    return results
