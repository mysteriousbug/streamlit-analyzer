"""Extract tables from .xlsx files using openpyxl.

Excel is trickier than PPTX/PDF because tables aren't explicitly delimited -
we scan each sheet for the title text of a known table type, then treat the
next block of contiguous rows as the table.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from openpyxl import load_workbook

from models import MetricRow, TableType
from normalizer import find_header_row, normalize_table


def _cell_str(v) -> str:
    if v is None:
        return ""
    return str(v).strip()


def _scan_sheet_for_tables(ws) -> list[tuple[TableType, str, int, int, int]]:
    """Scan a sheet for regions matching known table types.

    Returns list of (table_type, heading_text, start_row, end_row, max_col).
    Heuristic: find a cell whose text matches a TableType. The table is the
    contiguous block of rows below it (stopping at 2+ consecutive blank rows).
    """
    rows = list(ws.iter_rows(values_only=True))
    findings = []

    for r_idx, row in enumerate(rows):
        for c_idx, val in enumerate(row):
            text = _cell_str(val)
            if not text:
                continue
            tt = TableType.match(text)
            if tt is None:
                continue

            # Find end of block
            blank_run = 0
            end = r_idx
            max_col = len([c for c in rows[r_idx + 1] if _cell_str(c)]) if r_idx + 1 < len(rows) else 0

            for r2 in range(r_idx + 1, len(rows)):
                non_empty = [c for c in rows[r2] if _cell_str(c)]
                if not non_empty:
                    blank_run += 1
                    if blank_run >= 2:
                        break
                else:
                    blank_run = 0
                    end = r2
                    max_col = max(max_col, len(non_empty))

            if end > r_idx:
                findings.append((tt, text, r_idx + 1, end, max_col))
    return findings


def extract_from_xlsx(
    path: Path,
    domain_hint: str = "",
) -> list[MetricRow]:
    """Extract metric rows from an xlsx file."""
    wb = load_workbook(filename=str(path), data_only=True, read_only=True)
    results: list[MetricRow] = []

    for ws in wb.worksheets:
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            continue
        sheet_name = ws.title

        findings = _scan_sheet_for_tables(ws)

        if findings:
            for table_type, heading, start_row, end_row, max_col in findings:
                raw = [
                    [_cell_str(c) for c in rows[r][:max_col + 5]]
                    for r in range(start_row, end_row + 1)
                ]
                metrics = normalize_table(
                    raw_table=raw,
                    table_type=table_type,
                    source_file=str(path),
                    domain=domain_hint,
                    subdomain=sheet_name,
                )
                results.extend(metrics)
        else:
            # Fallback: sheet name itself may indicate table type
            tt = TableType.match(sheet_name)
            if tt is None:
                continue
            raw = [[_cell_str(c) for c in row] for row in rows]
            if find_header_row(raw) is None:
                continue
            metrics = normalize_table(
                raw_table=raw,
                table_type=tt,
                source_file=str(path),
                domain=domain_hint,
                subdomain=sheet_name,
            )
            results.extend(metrics)

    wb.close()
    return results
