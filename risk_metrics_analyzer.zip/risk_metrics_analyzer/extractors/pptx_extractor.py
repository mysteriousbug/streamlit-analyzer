"""Extract tables from .pptx files using python-pptx."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from pptx import Presentation
from pptx.util import Emu

from models import MetricRow, TableType
from normalizer import normalize_table


def _shape_text(shape) -> str:
    """Extract all text from a shape."""
    if not shape.has_text_frame:
        return ""
    return "\n".join(p.text for p in shape.text_frame.paragraphs).strip()


def _table_to_rows(table) -> list[list[str]]:
    """Convert a pptx table to list-of-lists of strings."""
    rows = []
    for row in table.rows:
        rows.append([cell.text.strip() for cell in row.cells])
    return rows


def _find_nearest_title_above(slide, table_shape) -> Optional[str]:
    """Find the text shape whose bottom edge is closest above the table.

    Used to identify the table type from a heading like 'Breached KCI'.
    """
    table_top = table_shape.top or 0
    best_shape = None
    best_distance = None
    for shape in slide.shapes:
        if shape == table_shape:
            continue
        if not shape.has_text_frame:
            continue
        text = _shape_text(shape)
        if not text:
            continue
        shape_bottom = (shape.top or 0) + (shape.height or 0)
        if shape_bottom > table_top:
            continue  # Not above
        distance = table_top - shape_bottom
        if best_distance is None or distance < best_distance:
            best_distance = distance
            best_shape = shape
    return _shape_text(best_shape) if best_shape else None


def _slide_title(slide) -> str:
    """Try to extract the slide's title text."""
    if slide.shapes.title is not None:
        return _shape_text(slide.shapes.title)
    # Fallback: highest text shape
    text_shapes = [s for s in slide.shapes if s.has_text_frame and _shape_text(s)]
    if not text_shapes:
        return ""
    top = min(text_shapes, key=lambda s: s.top or 0)
    return _shape_text(top)


def extract_from_pptx(
    path: Path,
    domain_hint: str = "",
) -> list[MetricRow]:
    """Extract all metric rows from a pptx file.

    Domain is taken from `domain_hint` (e.g. derived from folder/filename).
    Subdomain is taken from slide title. Table type is inferred from the
    heading immediately above each table.
    """
    prs = Presentation(str(path))
    results: list[MetricRow] = []

    for slide in prs.slides:
        subdomain = _slide_title(slide) or ""
        for shape in slide.shapes:
            if not shape.has_table:
                continue
            heading_text = _find_nearest_title_above(slide, shape) or ""
            # Also try looking inside the table's first row for a title
            table_type = TableType.match(heading_text)
            if table_type is None:
                # Sometimes the title is the slide title itself
                table_type = TableType.match(subdomain)
            if table_type is None:
                continue

            raw = _table_to_rows(shape.table)
            rows = normalize_table(
                raw_table=raw,
                table_type=table_type,
                source_file=str(path),
                domain=domain_hint,
                subdomain=subdomain,
            )
            results.extend(rows)
    return results
